package com.cg.payroll.client;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;

public class MainClass 
{

	public static void main(String[] args) throws AssociateDetailsNotFoundException {
		PayrollServices services=new PayrollServicesImpl();
		int associateId=services.acceptAssociateDetails("Gunjan", "Vohra","gunjanv@gmail.com","Student","AnalystA4","gunjanv598",10000,550000,12000,12000,100050,"icici bank","5678");
		int associateId1=services.acceptAssociateDetails("ankita", "dhar","ankitadhar06@gmail.com","Student","SoftwareEngineer","tair137",10000,350000,12000,12000,100050,"sbi bank","7864");
		int associateId2=services.acceptAssociateDetails("nishtha", "thakur","nishthathakur@gmail.com","Analyst","AnalystA4","shivi45",10000,670000,12000,12000,100050,"sbi bank","4538");
		int associateId3=services.acceptAssociateDetails("Harpreet", "Kaur","harpreetk12@gmail.com","Student","TechnicalAssociate","hrk897",10000,350000,12000,12000,100050,"icici bank","3298");
		int associateId4=services.acceptAssociateDetails("samreeti", "sharma","samreetisharma@gmail.com","Student","SeniorAssociate","kkp754",10000,750000,12000,12000,100050,"citi bank","cit12334");
		try {
		     System.out.print("Associate Id "+PayrollDBUtil.getASSOCIATE_ID_COUNTER()+" -----Net Annual salary : "+services.calculateNetSalary(associateId));
		     double monNetSalary=(services.calculateNetSalary(associateId))/12;
		     System.out.println(" ------  monthly net salary: "+monNetSalary);
		    
		     
		     System.out.print("Associate Id "+PayrollDBUtil.getASSOCIATE_ID_COUNTER()+" -----Net Annual salary: "+services.calculateNetSalary(associateId1));
		    double monNetSalary1=(services.calculateNetSalary(associateId1))/12;
		    System.out.println(" ------  monthly net salary: "+monNetSalary1);
		    
		    System.out.print("Associate Id "+PayrollDBUtil.getASSOCIATE_ID_COUNTER()+" -----Net Annual salary: "+services.calculateNetSalary(associateId2));
		    double monNetSalary2=(services.calculateNetSalary(associateId2))/12;
		    System.out.println(" ------  monthly net salary: "+monNetSalary2);
		    
		    System.out.print("Associate Id "+PayrollDBUtil.getASSOCIATE_ID_COUNTER()+" -----Net Annual salary: "+services.calculateNetSalary(associateId3));
		    double monNetSalary3=(services.calculateNetSalary(associateId3))/12;
		    System.out.println(" ------  monthly net salary: "+monNetSalary3);
		    
		    System.out.print("Associate Id "+PayrollDBUtil.getASSOCIATE_ID_COUNTER()+" -----Net Annual salary: "+services.calculateNetSalary(associateId4));
		    double monNetSalary4=(services.calculateNetSalary(associateId4))/12;
		    System.out.println(" ------  monthly net salary: "+monNetSalary4);
		    

		}
		catch(AssociateDetailsNotFoundException e)
		{
			e.printStackTrace();
		}
	}

}


